import { Box, Typography, Button } from '@mui/material';
import { useState, useEffect } from 'react';

interface PrayerResultProps {
  prayer: string;
  onEdit: () => void;
  onSave: (editedContent: string) => void;
  onPrint: () => void;
  onSaveToWord: () => void;
  onTTS: () => void;
  onSaveToPrayerList: () => void;
}

export default function PrayerResult({
  prayer,
  onEdit,
  onSave,
  onPrint,
  onSaveToWord,
  onTTS,
  onSaveToPrayerList,
}: PrayerResultProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedPrayer, setEditedPrayer] = useState(prayer);

  useEffect(() => {
    setEditedPrayer(prayer);
  }, [prayer]);

  const handleEdit = () => {
    setIsEditing(true);
    onEdit();
  };

  const handleSave = () => {
    setIsEditing(false);
    onSave(editedPrayer);
  };

  // 마크다운을 HTML로 변환하는 함수
  const convertToHtml = (text: string) => {
    // ## 로 시작하는 헤더를 변환
    let html = text.replace(/## (.*)\n/g, '<h2 style="color: #1976d2; font-size: 1.2rem; margin-top: 1.5rem; margin-bottom: 1rem;">$1</h2>');
    
    // 볼드체 변환 (**텍스트**)
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong style="font-weight: 600;">$1</strong>');
    
    // 이탤릭체 변환 (*텍스트*)
    html = html.replace(/\*(.*?)\*/g, '<em style="color: #666;">$1</em>');
    
    // 인용구 변환 (> 텍스트)
    html = html.replace(/> (.*)\n/g, '<blockquote style="border-left: 4px solid #90caf9; padding-left: 1rem; margin: 1rem 0; background-color: #f5f5f5;"><p style="margin: 0.5rem 0;">$1</p></blockquote>');
    
    // 줄바꿈 처리
    html = html.replace(/\n\n/g, '</p><p style="margin: 1rem 0;">');
    html = html.replace(/\n/g, '<br>');
    
    // 전체 텍스트를 p 태그로 감싸기
    html = `<p style="margin: 1rem 0;">${html}</p>`;
    
    return html;
  };

  return (
    <Box>
      <Box sx={{ mt: 2, mb: 3 }}>
        {isEditing ? (
          <textarea
            value={editedPrayer}
            onChange={(e) => setEditedPrayer(e.target.value)}
            style={{
              width: '100%',
              minHeight: '300px',
              padding: '1rem',
              fontSize: '1rem',
              lineHeight: '1.8',
              fontFamily: '"나눔명조", serif',
            }}
          />
        ) : (
          <Box
            sx={{
              border: '1px solid',
              borderColor: 'divider',
              borderRadius: 1,
              p: 3,
              backgroundColor: '#fff',
              fontFamily: '"나눔명조", serif',
              fontSize: '1rem',
              lineHeight: 1.8,
              color: 'text.primary',
              '& h2': {
                color: 'primary.main',
                fontSize: '1.2rem',
                fontWeight: 600,
                mt: 3,
                mb: 2,
                '&:first-of-type': {
                  mt: 0  // 첫 번째 헤더의 상단 여백 제거
                }
              },
              '& blockquote': {
                borderLeft: '4px solid',
                borderColor: 'primary.light',
                bgcolor: 'grey.50',
                px: 2,
                py: 1,
                my: 2,
              },
              '& p': {
                my: 1.5  // 문단 간격 조정
              }
            }}
            dangerouslySetInnerHTML={{ __html: convertToHtml(editedPrayer) }}
          />
        )}
      </Box>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button
            variant="contained"
            onClick={isEditing ? handleSave : handleEdit}
          >
            {isEditing ? '수정 완료' : '수정하기'}
          </Button>
          <Button variant="outlined" onClick={onPrint}>
            출력하기
          </Button>
          <Button variant="outlined" onClick={onSaveToWord}>
            Word 저장
          </Button>
          <Button variant="outlined" onClick={onTTS}>
            음성 낭독
          </Button>
        </Box>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={onSaveToPrayerList}
        >
          기도문 저장
        </Button>
      </Box>
    </Box>
  );
} 